package firstExam; 

//범위 설정 -> Ctrl + Shift + F  : 코드 정리
// Ctrl + Alt + 위/아래 방향키 : 줄 단위 복사
// Ctrl + D  : 줄 제거
public class FirstVariable {  // 클래스 시작
	public static void main(String[] args) {  //main 메소드 시작
		System.out.print("Hello, Java!!\n");  
		System.out.print("즐거운 시간!!");  
		System.out.print("자바는 즐거워!!");  
		
	} //end of main
} //end of class
