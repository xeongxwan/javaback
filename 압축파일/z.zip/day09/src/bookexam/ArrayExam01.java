package bookexam;

public class ArrayExam01 {

	public static void main(String[] args) {
		//	1	2	3	4	5
		//	6	7	8	9	10
		//	11	12	13	14	15
		//	16	17	18	19	20
		//	21	22	23	24	25
	
		int k = 1; // 증가하는 숫자를 담을 변수
		
		for(int i=0; i<5; i++) {
			for(int j=0; j<5; j++) {
				
				//System.out.print(k + " ");
				System.out.printf("%-5d",k);
				k++;	// k = k + 1; k += 1;
			}	//안쪽 for문 끝
			System.out.println();
		}	//밖 for문 끝
		
		
	

			
		
		
		
		
		
		
	}//end of main

}//end of class
