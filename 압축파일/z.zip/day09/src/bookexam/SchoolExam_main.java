package bookexam;

public class SchoolExam_main {

	public static void main(String[] args) {
	
			SchoolExam a = new SchoolExam("Songjunghyuk","Beolmal",6);
			
			//붕어빵 먹기
			a.showInfo();
			
		
	
	}
	}


