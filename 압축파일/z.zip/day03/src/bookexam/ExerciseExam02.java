package bookexam;

public class ExerciseExam02 {

	public static void main(String[] args) {
		int value = 356;
		System.out.println(value / 100*100);
		
		// 정수	/	정수	=> 정수
		int result = (value / 100);
		System.out.println(result);
		
		int result01 = (value/100) * 100;
		System.out.println(result01);
		
	}

}
