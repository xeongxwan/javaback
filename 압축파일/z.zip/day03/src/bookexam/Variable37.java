package bookexam;

public class Variable37 {

	public static void main(String[] args) {
//		int value;	//변수를 선언과 동시에 되도록 초기화
//					//변수를 선언하면 반드시 그 변수에 값을 담아 주어야 사용할 수 있다.
//		
//		int result = value + 10;
//					// value라는 변수에 값이 담겨 있지 않기 때문에
//		System.out.println(result);

		// int value=0
		int value=5;	//int value;
						// value =5;
		
int result = value + 10;
		
System.out.println(result);
		
	}

}
