package loopexam;

public class ForExam07 {

	public static void main(String[] args) {

		
		
		int dan = 3;
		
		for(int i=1; i<=9; i++) {
//			System.out.println(dan + "*" + i +  "=" + (dan*i));
			System.out.printf("%d*%d= %d\n",dan,i,dan*i);
		}
	}

}
