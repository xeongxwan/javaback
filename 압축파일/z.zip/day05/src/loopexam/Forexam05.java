package loopexam;

public class Forexam05 {

	public static void main(String[] args) {
		 int count = 0;
		 for(int i=1; i<2023; i++) {
			 if(i % 4 ==0) {
				 count++; 
				 System.out.println("4의 배수의  = " + i);
				 System.out.println("4의 배수의 개수 = " + count);
			 }
			 //if(i % 4 ==0) count++;
		 }
			//505
	}

}
