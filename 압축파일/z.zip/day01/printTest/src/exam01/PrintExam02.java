package exam01;

public class PrintExam02 {

	public static void main(String[] args) {
		// 출력 형태
		// ==========================================
		// 반	번호	이름	국어	영어 	수학
		// ==========================================
		// 1	 1		홍길동	 75		 85		 92
		
//		System.out.println("==========================================");
//		System.out.println("반    번호    이름    국어    영어    수학");
//		System.out.println("==========================================");
//		System.out.println("1     1       홍길동   75     85       92");
		System.out.println("============================================");
		System.out.println("반\t번호\t이름\t국어\t영어\t수학");
		System.out.println("============================================");
		System.out.println("1\t1\t홍길동\t75\t85\t92");
		}
}
