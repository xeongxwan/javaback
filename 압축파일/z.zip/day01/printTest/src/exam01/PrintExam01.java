package exam01;

public class PrintExam01 {
	public static void main(String[] args) {
		System.out.println("Hello!!");
		System.out.println("이름 : 홍길동");
		System.out.println("나이 : 25");
		System.out.println("주소 : 경기도 하남시");
		
	}
}
