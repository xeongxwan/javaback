package variableExam;

public class Variable02 {

	public static void main(String[] args) {
//		int kor = 100;
//		int eng = 90;
//		int mat = 80;
		int kor = 100, eng = 90, mat = 80;
		int sum = kor + eng + mat;
		
		System.out.println("국어 = " + kor);
		System.out.println("영어 = " + eng);
		System.out.println("수학 = " + mat);
		System.out.println("합계 = " + sum);

	}

}



