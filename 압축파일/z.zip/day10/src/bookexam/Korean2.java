package bookexam;

public class Korean2 {
//필드선언
	String nation = "대한민국";
	String name;
	String ssn;
	
	//생성자 선언
	public Korean2(String name, String ssn) {
		this.name = name;
		this.ssn = ssn;
	}
}
