package exam;

public class ClassExam {

	public static void main(String[] args) {

	}

}
