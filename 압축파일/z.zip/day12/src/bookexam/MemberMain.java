package bookexam;

public class MemberMain {

	public static void main(String[] args) {
		
		Member hong = new Member("name","id");
		System.out.println(hong.name + hong.id);
	
		
	
	}

}
