package bookexam;

public class Member {
	String name;
	String id;
	String password;
	int age;
	
	Member(String name,String id){
		this.name = "홍길동";
		this.id = "hong";

	}

	
	
	


}
