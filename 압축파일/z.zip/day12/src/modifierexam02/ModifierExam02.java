package modifierexam02;

public class ModifierExam02 {

	
}
