package modifierexam02;

public class ModifierMain02 {

}
