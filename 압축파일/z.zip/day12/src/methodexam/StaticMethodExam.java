package methodexam;

public class StaticMethodExam {
	
	static int snum = 6;
	
	public static int sadd(int x, int y) {
		return x + y;
	}

}
