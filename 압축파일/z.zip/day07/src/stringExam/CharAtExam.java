package stringExam;

public class CharAtExam {

	public static void main(String[] args) {
		String str = "";
		String strTest = "자바는 즐거워";
		
		//str이 공란이냐 비교 
		System.out.println(str.equals(""));
		
		//strTest에서 '즐'자만 추출
		System.out.println(strTest.charAt(4));
		System.out.println();
		
		//문자열의 길이 : strTest.length()
		for(int i=0; i<strTest.length() ; i++) {
		System.out.println(strTest.charAt(i));
		}
		
	}

}
