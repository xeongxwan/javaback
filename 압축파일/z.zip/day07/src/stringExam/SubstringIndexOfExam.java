package stringExam;

public class SubstringIndexOfExam {

	public static void main(String[] args) {
		String hobby = "자바로 프로그램 만들기";
		String ssn = "980304-1234567";
		
		//#1. hobby에서 '그램'의 위치찾기 - indexOf()
		System.out.println(hobby.indexOf("그램"));
		
		//#2. ssn에서 생년월일 추출(980304) - substring
		System.out.println(ssn.substring(0,7));//980304, 시작인덱스부터 끝인덱스-1 까지 추출
		
		//#3. ssn에서 성별만 추출하기 - substring() : 문자열로 추출
		System.out.println(ssn.substring(7,8));	//1
		
		
		//#4. ssn에서 9번째(인덱스번호로는 8부터)는 "****"로 표시 - replace()
		System.out.println(ssn.replace(("234567"),"*****"));	//980304-1*****
	}

}
