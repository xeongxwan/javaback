package stringExam;

public class ReferenceExam {

	public static void main(String[] args) {
		String hobby = "여행";
		String name = "홍길동";
		int	age = 23;
		
		System.out.println(name + "님의 나이는 " + age + "살이고 취미는" + hobby);
		
		
		hobby = null;	//hobby가 담고 있는 객체의 주소 대신 null을 담음
						//힙영역에 생성된 "여행" 객체는 더이상 참조하는 것이 없으므로
						//메모리에서 제거
		System.out.println(name + "님의 나이는 " + age + "살이고 취미는" + hobby);
		
		hobby = name;	//hobby가 담고 있는 변수에 name이 담고 객체의 주소를 복사
						//
		System.out.println(name + "님의 나이는 " + age + "살이고 취미는" + hobby);
		
	}

}
