package stringExam;

public class SplitExam {

	public static void main(String[] args) {
		//#1. 변수 선언 및 값 초기화
		String ssn = "980304-1234567";
		String str = " 국어, 영어, 수학, 합계";
		
		//#2. 배열 선언
		String[] ssnSplit = new String[2];
		String[] strSplit = new String[5];
		
		//#3. 문자열을 구분자로 나눈 뒤 배열 담기
		ssnSplit = ssn.split("-");
		strSplit = str.split(",");
		
		//#4.배열에 담긴 내용을 출력
		for(int i=0; i<ssnSplit.length; i++) {
			System.out.println(ssnSplit[i]);
		}
		System.out.println();
		
		for(int i=0; i<strSplit.length; i++) {
			System.out.println(strSplit[i]);
		}
		
		
		
	}

}
