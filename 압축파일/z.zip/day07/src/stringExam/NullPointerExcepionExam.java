package stringExam;

public class NullPointerExcepionExam {

	public static void main(String[] args) {
		int[] ban = new int[3];
		ban[0] = 10;
		ban[1] = 20;
		ban[2] = 30;
		
		int[] intArray = null;// 참조하는 객체가 아직은 없음
		
		System.out.println("ban[1] : " + ban[1]);	//bam[1] : 20
		System.out.println("intArray[1] : " + intArray[1] ); //NullPointerException
												//참조하는 객체가 없는데 읽어오라 해서 생긴 예외
		
	}

}
