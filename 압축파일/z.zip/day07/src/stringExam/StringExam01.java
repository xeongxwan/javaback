package stringExam;

public class StringExam01 {

	public static void main(String[] args) {
		int num1 = 20;
		int num2 = 20;
		int num3 = 30;
		
		
		String str01 = "홍길동";
		String str02 = "홍길동";
		String str03 = "김자바";
		String str04 = new String("홍길동");
		String str05 = new String("홍길동");
		
		System.out.println("num1 == num2 : " + (num1==num2));	//true
		System.out.println("num1 == num3 : " + (num1==num3));	//false
		System.out.println("num1 != num3 : " + (num1!=num3));	//true
		System.out.println();
		
		//Strong의 참조변수가 담고 있는 값을 비교, 주소(번지)를 비교
		System.out.println("str01 == str02 : " + (str01 == str02));	//true
		System.out.println("str02 == str03 : " + (str02 == str03));	//false
		System.out.println("str01 == str04 : " + (str01 == str04));	//false
		System.out.println("str01 == str05 : " + (str01 == str05));	//false
		System.out.println("str03 == str04 : " + (str03 == str04));	//false
		System.out.println("str03 != str04 : " + (str03 != str04));	//true
		System.out.println();
		
		//문자열을 비교(참조변수가 가리키고 있는 객체의 값을 비교)
		//비교할문자1.equals(비교할문자2)	=> 문자1과 문자2가 같은지 비교
		System.out.println("str01.equals(str04) : " + str01.equals(str04));
		//위 결과와 비교하기(여긴 참조 변수가 담고 있는 객체의 주소 비교)
		System.out.println("str01 == str04 : " + (str01 == str04));	//false		
	}

}
