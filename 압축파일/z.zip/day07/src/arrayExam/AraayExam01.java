package arrayExam;

import java.util.Arrays;

public class AraayExam01 {

	public static void main(String[] args) {
		//int[] intArray = {1.0,"rk", 10}; //에러, 배열은 동일한 자료령만 저장 가능
											//intArray는 정수형으로 정수형만 담을 수 있음
		
		// #1. 배열선언
		int[] intArray1 = {10, 20, 30};
		//#2. 배열을 출력(배열에 담긴 값 읽기)
		System.out.println(intArray1[0]);	//배열에 담긴 값 읽기
		System.out.println(intArray1[1]);
		System.out.println(intArray1[2]);
		System.out.println();
		//#3. 배열의 2번째 요소의 값을 75로 변경 (배열의 요소값 변경)
		intArray1[2] = 75;
		System.out.println(intArray1[2]);
		System.out.println();
		
		
		//#4. 배열 선언
		int[] intArray2 = new int[3];
		
		//#4_1 배열 요소에 값 담기
		intArray2[0] = 100;
		intArray2[1] = 200;
		intArray2[2] = 300;
		
		//#4_2. 배열 요소의 값 출력1
		System.out.println(intArray2[0]);
		System.out.println(intArray2[1]);
		System.out.println(intArray2[2]);
		System.out.println();
		
		//#4_3. 배열 요소의 값 출력방법-2 for 이용
		for(int i=0; i<intArray2.length; i++) {
			System.out.println(intArray2[i]);
		
		}
		System.out.println();
		
		
		//#4_4. 배열 요소의 값 출력방법-3 Arrays.toString()
		System.out.println(Arrays.toString(intArray2)); //[100, 200, 300]
		//import : Alt + Shift + o
		System.out.println();
		
		//#4_5. 배열 요소의 값 출력방법-4 향상된for문
		for(int num : intArray2) { // [100 200 300]
			System.out.println(num);
		}
		
		
			

	}

}
