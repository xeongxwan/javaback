package arrayExam;

public class ArrayExam02 {
public static void main(String[] args) {
	

		int[] score= {83,90,97};
		
		int sum = 0;
		double avg = 0.0;
	
		//합계
//		for(int i = 0; i<score.length; i++) {
//			sum += score[1]; // sum = sum + score[i]
//		}
		for(int jumsu : score){
			sum = sum +jumsu; //sum += jumsu;
		}
		
		//평균 = 합계 / 배열의 길이 (=요소의 개수)
		avg = (double) sum / score.length;	//avg = (double)sum / 3;
		
		System.out.println("합계 = " + sum);
		System.out.println("평균 = " + avg);
		}
}
