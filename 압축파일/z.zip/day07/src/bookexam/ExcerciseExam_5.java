package bookexam;

public class ExcerciseExam_5 {

	public static void main(String[] args) {
		for(int x=1; x<10; x++) {	//x의 범위
			for(int y=1; y<=10; y++) { //y의 범위
				if(4*x + 5*y == 60) {
					System.out.println("(" + x +"," + y +")");
				}//end of if	
			}//안쪽 for 끝
		}//밖 for 끝
			
	
	}//end of main

}//end of class
