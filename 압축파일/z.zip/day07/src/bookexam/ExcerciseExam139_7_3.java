package bookexam;

import java.util.Scanner;

public class ExcerciseExam139_7_3 {

	public static void main(String[] args) {
		Scanner scan= new Scanner(System.in);
		
		//예금-deposit, 출금withdrawal, 잔고balance
		int deposit=0, withdrawal =0, balance=0;
		boolean run=true;
		
		while(run) {
			int selectNo=0;
			System.out.println("--------------------------------");
			System.out.println("1.예금 | 2.출금 | 3.잔고 | 4.종료");
			System.out.println("--------------------------------");
			System.out.println("선택 > ");
			selectNo = Integer.parseInt(scan.next());
			
			switch(selectNo) {
			case 1 :
				System.out.println("예금액>");
				deposit = deposit + scan.nextInt();
				balance = balance + deposit;
				break;
			case 2 :
				System.out.println("출금액>");
				withdrawal =  (scan.nextInt());
				balance = balance - withdrawal;
				break;
			case 3 :
				System.out.println("잔고>" + balance);
				break;
			case 4 :
				System.out.println("프로그램 종료");
				run = false;
				break;
			}//end of if
					
			
			
			
			
			
	
			
		}//end of while
		//int selectNo = Integer.parseInt(scan.nextLine());
		
	}//end of main
	

}//end of class
