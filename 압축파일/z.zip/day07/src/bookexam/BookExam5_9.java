package bookexam;

import java.util.Scanner;

public class BookExam5_9 {

	public static void main(String[] args) {
		
			Scanner scan= new Scanner(System.in);
			
			
			int students= 0, scoreList=0,array=0;
			boolean run=true;
			int[] score = new int[0];
			
			while(run) {
				int selectNo=0;
				String num = "";
				System.out.println("------------------------------------------------------");
				System.out.println("1.학생수 | 2.점수입력 | 3.점수리스트 | 4.분석 | 5.종료");
				System.out.println("-------------------------------------------------------");
				System.out.println("선택 > ");
				num = scan.next();
			
			if(num.equals("1")) {
				System.out.println("학생수 >");
				students = scan.nextInt();
		
				
			}else if(num.equals("2")){
				
					
				
			}else if(num.equals("3")){
				
				
				
			}else if(num.equals("4")){
				
				
				
			}else {
				System.out.println("프로그램 종료");
				break;
			
			}
		
		
			
			
			
			
			
			
		}//end of while
	
		
			
		}//end of main
	}//end of class


