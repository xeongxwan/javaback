package bookexam;

public class ExerciseExam6139 {
	public static void main(String[] args) {
		for(int i=1; i<=5; i++) {
			for(int j=1; j<=i; j++) {
				System.out.print("*");
			}//안쪽 for문 끝
			System.out.println();
		}//밖 for문 끝
	}
}
