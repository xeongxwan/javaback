package bookexam;

import java.util.Scanner;

public class ExcerciseExam139_7_2 {

	public static void main(String[] args) {
		Scanner scan= new Scanner(System.in);
		
		//예금-deposit, 출금withdrawal, 잔고balance
		int deposit=0, withdrawal =0, balance=0;
		boolean run=true;
		
		while(run) {
			int selectNo=0;
			String num = "";
			System.out.println("--------------------------------");
			System.out.println("1.예금 | 2.출금 | 3.잔고 | 4.종료");
			System.out.println("--------------------------------");
			System.out.println("선택 > ");
			num = scan.next();
			//selectNo = Integer.parseInt(scan.next());
			
			if(num.equals("1")) {	//selectNo == 1
				System.out.println("예금액>");
				deposit = scan.nextInt();
				balance = balance + deposit;
			}else if(num.equals("2")) { //selectNo == 2
				System.out.println("출금액>");
				withdrawal = scan.nextInt();
				balance = balance - withdrawal;
				
			}else if(num.equals("3")) { //selectNo == 3
				System.out.println("잔고>" + balance);
				
			}else {
				System.out.println("프로그램 종료");
				break;
			
			}//end of if
					
			
			
			
			
			
	
			
		}//end of while
		//int selectNo = Integer.parseInt(scan.nextLine());
		
	}//end of main
	

}//end of class
