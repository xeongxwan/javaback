package operator;

public class Operator02 {

	public static void main(String[] args) {
		char a = 80;
		
		System.out.println(a
				);
		
	}
}
