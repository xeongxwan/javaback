package operatorExam;

public class Operator02 {

	public static void main(String[] args) {
		int a = 65	
				System.out.println(a);
	}
}
