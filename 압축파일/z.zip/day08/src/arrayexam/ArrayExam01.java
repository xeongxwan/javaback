package arrayexam;

import java.util.Scanner;

public class ArrayExam01 {

	public static void main(String[] args) {
	scanner scan= new
	}

}
