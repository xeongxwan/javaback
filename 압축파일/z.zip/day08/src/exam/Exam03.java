package exam;

public class Exam03 {

	public static void main(String[] args) {
		
	String[][] fruits = {  
					  {"apple", "사과"},
					 { "watermelon", "수박"},
					 {"peach", "복숭아"},
					{"strawberry", "딸기"},
					{"tangerine", "귤"}
					}
	
	}

}
