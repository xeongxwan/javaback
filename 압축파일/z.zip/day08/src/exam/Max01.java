package exam;

public class Max01 {

	public static void main(String[] args) {

		   boolean stop = false;

		   if() {

		     System.out.println("멈춤"); 

		   }else {

		     System.out.println("출발"); 

		   }
}
}
