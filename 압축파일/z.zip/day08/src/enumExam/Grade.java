package enumExam;

public enum Grade {
	VIP,
	GOLD,
	SIRVER,
	GENERAL
}
