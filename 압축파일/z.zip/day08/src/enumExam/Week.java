package enumExam;

public enum Week {	//열거 타입 이름
	MONDAY,			//열거 상수
	TUESDAY,
	WENDESDAY,
	THURSDAY,
	FRIDAY,
	SATURDAY,
	SUNDAY

}
